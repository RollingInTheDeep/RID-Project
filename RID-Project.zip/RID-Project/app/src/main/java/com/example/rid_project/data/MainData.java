package com.example.rid_project.data;

public class MainData {
    private String tvBookName;

    public MainData(String tvBookName) {
        this.tvBookName = tvBookName;
    }

    public String getTvBookName() {
        return tvBookName;
    }

    public void setTvBookName(String tvBookName) {
        this.tvBookName = tvBookName;
    }
}
